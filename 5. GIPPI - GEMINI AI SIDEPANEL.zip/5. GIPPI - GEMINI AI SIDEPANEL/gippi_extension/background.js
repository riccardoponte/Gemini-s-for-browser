// Crea il menu contestuale (tasto destro) come alternativa
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "ask-gippi",
    title: "Chiedi a Gippi",
    contexts: ["selection"]
  });
});

// Gestisce il click sul menu contestuale
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "ask-gippi") {
    // Apri il pannello laterale
    chrome.sidePanel.open({ windowId: tab.windowId });
    // Salva il testo nella memoria (innescherà l'incolla in tempo reale)
    chrome.storage.local.set({ pendingPrompt: info.selectionText });
  }
});

// Gestisce il click sul pulsante fluttuante
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "open_gippi_from_tooltip") {
    // Apri il pannello laterale
    chrome.sidePanel.open({ windowId: sender.tab.windowId });
    // Salva il testo nella memoria
    chrome.storage.local.set({ pendingPrompt: message.text });
  }
});

// Configura il pannello all'azione dell'icona in alto a destra
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));