# Gippi AI Sidepanel Extension

Questa estensione per Google Chrome consente di utilizzare i servizi di **Google Gemini** e **Claude AI** direttamente in un pannello laterale richiudibile e regolabile.

## Funzionalità
- **Pannello Laterale**: Accedi a Gemini e Claude senza cambiare scheda.
- **Chiedi a Gippi**: Seleziona del testo su qualsiasi pagina web, clicca con il tasto destro e scegli "Chiedi a Gippi". Il testo verrà copiato negli appunti e il pannello si aprirà automaticamente per permetterti di incollarlo nella chat.
- **Interfaccia Pulita**: Passa facilmente da un'IA all'altra tramite i pulsanti in alto.

## Come Installare
1. Scarica ed estrai il file `gippi_extension.zip`.
2. Apri Chrome e vai a `chrome://extensions/`.
3. Attiva la **Modalità sviluppatore** (Developer mode) in alto a destra.
4. Clicca su **Carica estensione non impacchettata** (Load unpacked) e seleziona la cartella estratta.
5. Clicca sull'icona del puzzle (Estensioni) nella barra di Chrome e blocca "Gippi AI Sidepanel" per un accesso rapido.

## Note sulla Sicurezza
A causa delle restrizioni di sicurezza di Google e Anthropic (Same-Origin Policy), l'estensione non può "digitare" o "inviare" automaticamente il testo all'interno dell'iframe. La funzione "Chiedi a Gippi" copia il testo negli appunti per te; dovrai solo incollarlo (Ctrl+V) e premere invio nella chat aperta.
