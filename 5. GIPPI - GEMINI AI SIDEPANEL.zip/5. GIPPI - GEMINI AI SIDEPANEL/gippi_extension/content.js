let gippiTooltip = null;

// Rimuove il pulsante se clicchi da un'altra parte
document.addEventListener('mousedown', (e) => {
  if (gippiTooltip && !gippiTooltip.contains(e.target)) {
    gippiTooltip.remove();
    gippiTooltip = null;
  }
});

// Mostra il pulsante quando finisci di selezionare il testo
document.addEventListener('mouseup', (e) => {
  // Aspetta un istante per permettere al browser di registrare la selezione
  setTimeout(() => {
    const selectedText = window.getSelection().toString().trim();

    if (selectedText.length > 0) {
      showTooltip(e.pageX, e.pageY, selectedText);
    }
  }, 10);
});

function showTooltip(x, y, text) {
  // Se c'è già un tooltip aperto, lo rimuove
  if (gippiTooltip) gippiTooltip.remove();

  // Crea il pulsante
  gippiTooltip = document.createElement('div');
  gippiTooltip.innerHTML = "✨ Chiedi a Gippi";
  
  // Stili del pulsante fluttuante
  Object.assign(gippiTooltip.style, {
    position: 'absolute',
    top: `${y + 15}px`, // 15 pixel sotto il cursore
    left: `${x}px`,
    backgroundColor: '#131314', // Colore scuro stile Gemini
    color: '#ffffff',
    padding: '6px 12px',
    borderRadius: '8px',
    border: '1px solid #444',
    cursor: 'pointer',
    zIndex: '2147483647', // Valore massimo per stare sopra a tutto
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    fontFamily: 'sans-serif',
    fontSize: '13px',
    fontWeight: 'bold',
    transition: 'transform 0.1s ease',
    userSelect: 'none'
  });

  // Effetto hover
  gippiTooltip.onmouseover = () => gippiTooltip.style.transform = 'scale(1.05)';
  gippiTooltip.onmouseout = () => gippiTooltip.style.transform = 'scale(1)';

  // Cosa succede quando clicchi il pulsante
  gippiTooltip.addEventListener('click', (e) => {
    e.stopPropagation(); // Evita la chiusura immediata del pulsante
    
    // Invia un messaggio al background per aprire il pannello
    chrome.runtime.sendMessage({ 
      action: "open_gippi_from_tooltip", 
      text: text 
    });

    // Rimuove il pulsante
    gippiTooltip.remove();
    gippiTooltip = null;
    
    // Rimuove la selezione del testo per pulizia
    window.getSelection().removeAllRanges();
  });

  // Aggiunge il pulsante alla pagina
  document.body.appendChild(gippiTooltip);
}