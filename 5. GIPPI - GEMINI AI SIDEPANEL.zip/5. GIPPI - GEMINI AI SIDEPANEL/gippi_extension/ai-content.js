// 1. RIDUCE LO ZOOM DELLA PAGINA PER ADATTARSI AL PANNELLO
document.documentElement.style.zoom = "0.80";

// 2. FUNZIONE PER INSERIRE IL TESTO NELLA CHAT
function pasteIntoChat(text) {
  // Selettore specifico per l'interfaccia di Gemini
  const inputBox = document.querySelector('rich-textarea div[contenteditable="true"]');

  if (inputBox) {
    inputBox.focus();
    
    // Inserisce il testo
    document.execCommand('insertText', false, text);
    
    // FORZA Gemini ad accorgersi che abbiamo scritto qualcosa
    inputBox.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    // Aggiungiamo un evento keyup fittizio per aiutare ad abilitare il tasto Invia
    inputBox.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, cancelable: true, key: ' ', code: 'Space' }));
    
    return true; // Successo
  }
  return false; // Casella non ancora pronta
}

// 3. FUNZIONE CHE AVVIA IL CICLO DI INSERIMENTO
function executePaste(textToPaste) {
  let attempts = 0;
  // Ritenta finché non trova la casella (utile se Gemini sta caricando)
  const interval = setInterval(() => {
    if (pasteIntoChat(textToPaste)) {
      clearInterval(interval);
      chrome.storage.local.remove('pendingPrompt'); // Pulisce la memoria
    }
    attempts++;
    // Prova per 30 secondi (Gemini a volte è lento a caricare la UI)
    if (attempts > 60) clearInterval(interval); 
  }, 500);
}

// 4. CONTROLLA LO STORAGE AL CARICAMENTO INIZIALE DELLA PAGINA
function checkOnLoad() {
  chrome.storage.local.get(['pendingPrompt'], (result) => {
    if (result.pendingPrompt) {
      executePaste(result.pendingPrompt);
    }
  });
}

// Avvia il controllo all'apertura del frame
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkOnLoad);
} else {
    checkOnLoad();
}

// 5. ASCOLTA LO STORAGE IN TEMPO REALE (Per quando il pannello è già aperto)
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.pendingPrompt && changes.pendingPrompt.newValue) {
    executePaste(changes.pendingPrompt.newValue);
  }
});